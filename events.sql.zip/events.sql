-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Feb 23, 2016 at 11:27 PM
-- Server version: 5.5.42
-- PHP Version: 7.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `events`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` int(11) unsigned NOT NULL,
  `name` varchar(1024) NOT NULL,
  `description` text NOT NULL,
  `origin_url` varchar(2083) DEFAULT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `image` varchar(2083) NOT NULL COMMENT 'url',
  `rate` int(2) unsigned DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `name`, `description`, `origin_url`, `start`, `end`, `image`, `rate`, `created`) VALUES
(1, 'aaa - 5', 'php1 - 10, docker - 3', 'https://www.facebook.com', '2016-02-21 10:00:00', '2016-02-21 16:00:00', '/img/octopus.png', 5, '2016-02-07 23:00:00'),
(2, 'bbb - 10', 'node js 1 - 6, react 1 - 3', NULL, '2016-03-02 09:30:00', '2016-03-04 19:30:00', '/img/octopus.png', 10, '0000-00-00 00:00:00'),
(3, 'ccc - 4', 'startup 1 - 6', NULL, '2016-02-22 06:00:00', '2016-02-22 14:00:00', '/img/octopus.png', 4, '0000-00-00 00:00:00'),
(4, 'ddd - 5', 'node js 2 - 2, startup 2 - 4', NULL, '2016-02-21 10:00:00', '2016-02-21 18:00:00', '/img/octopus.png', 5, '0000-00-00 00:00:00'),
(5, 'eee - 7', 'php2 - 2, react 2 - 8', NULL, '2016-03-22 20:30:00', '2016-03-23 12:10:00', '/img/octopus.png', 7, '0000-00-00 00:00:00'),
(6, 'fff - 9', 'react 3 - 10', NULL, '2016-02-08 11:00:00', '2016-02-08 15:15:00', '/img/octopus.png', 9, '2016-02-07 23:00:00'),
(7, 'ggg - 1', 'node js 3 - 10', NULL, '2016-03-09 20:00:00', '2016-03-09 21:00:00', '/img/octopus.png', 1, '0000-00-00 00:00:00'),
(8, 'hhh - 2', 'php 3 - 8', NULL, '2016-02-09 10:00:00', '2016-02-09 13:00:00', '/img/octopus.png', 2, '2016-02-07 23:00:00'),
(9, 'iii - 7', 'startup 3 - 7, react 4 - 3, nodejs 4 - 3', NULL, '2016-03-11 08:00:00', '2016-03-11 16:00:00', '/img/octopus.png', 7, '2016-02-12 23:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `events_tags`
--

DROP TABLE IF EXISTS `events_tags`;
CREATE TABLE `events_tags` (
  `event_id` int(11) unsigned NOT NULL,
  `tag_id` int(11) unsigned NOT NULL,
  `rate` int(2) unsigned DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events_tags`
--

INSERT INTO `events_tags` (`event_id`, `tag_id`, `rate`, `created`) VALUES
(1, 1, 10, '0000-00-00 00:00:00'),
(1, 5, 3, '0000-00-00 00:00:00'),
(2, 2, 6, '0000-00-00 00:00:00'),
(2, 3, 3, '0000-00-00 00:00:00'),
(3, 4, 6, '0000-00-00 00:00:00'),
(4, 2, 2, '0000-00-00 00:00:00'),
(4, 4, 4, '0000-00-00 00:00:00'),
(5, 1, 2, '0000-00-00 00:00:00'),
(5, 3, 8, '0000-00-00 00:00:00'),
(6, 3, 10, '0000-00-00 00:00:00'),
(7, 2, 10, '0000-00-00 00:00:00'),
(8, 1, 8, '0000-00-00 00:00:00'),
(9, 2, 3, '0000-00-00 00:00:00'),
(9, 3, 3, '0000-00-00 00:00:00'),
(9, 4, 7, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `newsletters`
--

DROP TABLE IF EXISTS `newsletters`;
CREATE TABLE `newsletters` (
  `id` int(11) unsigned NOT NULL,
  `subject` varchar(76) NOT NULL,
  `newsletter_layout_id` int(11) unsigned NOT NULL,
  `newsletter_content_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `newsletters`
--

INSERT INTO `newsletters` (`id`, `subject`, `newsletter_layout_id`, `newsletter_content_id`, `created`) VALUES
(1, 'Test', 1, 1, '2016-02-06 17:30:24');

-- --------------------------------------------------------

--
-- Table structure for table `newsletters_contents`
--

DROP TABLE IF EXISTS `newsletters_contents`;
CREATE TABLE `newsletters_contents` (
  `id` int(11) unsigned NOT NULL,
  `content` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `newsletters_contents`
--

INSERT INTO `newsletters_contents` (`id`, `content`, `created`) VALUES
(1, '<div id="content">content</div>\n{control eventsList}', '2016-02-06 17:30:11');

-- --------------------------------------------------------

--
-- Table structure for table `newsletters_layouts`
--

DROP TABLE IF EXISTS `newsletters_layouts`;
CREATE TABLE `newsletters_layouts` (
  `id` int(11) unsigned NOT NULL,
  `layout` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `newsletters_layouts`
--

INSERT INTO `newsletters_layouts` (`id`, `layout`, `created`) VALUES
(1, '<html><body>{$content|noescape}</body><footer>footer</footer></html>', '2016-02-06 17:29:33');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags` (
  `id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(16) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `code`, `created`) VALUES
(1, 'PHP', 'php', '0000-00-00 00:00:00'),
(2, 'Node.js', 'nodejs', '0000-00-00 00:00:00'),
(3, 'ReactJS', 'reactjs', '0000-00-00 00:00:00'),
(4, 'Startup', 'startup', '0000-00-00 00:00:00'),
(5, 'Docker', 'docker', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL,
  `email` varchar(254) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `created`) VALUES
(1, 'kuba.zaba@gmail.com', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users_newsletters`
--

DROP TABLE IF EXISTS `users_newsletters`;
CREATE TABLE `users_newsletters` (
  `user_id` int(11) unsigned NOT NULL,
  `newsletter_id` int(11) unsigned NOT NULL,
  `variables` text NOT NULL,
  `hash` varchar(32) NOT NULL,
  `sent` datetime DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_newsletters`
--

INSERT INTO `users_newsletters` (`user_id`, `newsletter_id`, `variables`, `hash`, `sent`, `created`) VALUES
(1, 1, '["reactjs","startup"]', 'ev1cr8jozsv5cwqnt4pns0sxap2zzx4d', '2016-02-07 18:28:18', '2016-02-10 22:36:04'),
(1, 1, '["reactjs","startup"]', 'woumwgsl3lgil6oi9pfu76iswbdb67jj', '2016-02-14 18:28:18', '2016-02-14 15:19:29'),
(1, 1, '["reactjs","startup"]', 'xsky5g93zyu2y74b2wwi2jsz0dsa8aso', '2016-02-01 18:28:18', '2016-02-01 22:32:34');

-- --------------------------------------------------------

--
-- Table structure for table `users_tags`
--

DROP TABLE IF EXISTS `users_tags`;
CREATE TABLE `users_tags` (
  `user_id` int(11) unsigned NOT NULL,
  `tag_id` int(11) unsigned NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_tags`
--

INSERT INTO `users_tags` (`user_id`, `tag_id`, `created`) VALUES
(1, 3, '2016-02-06 17:56:34'),
(1, 4, '2016-02-10 22:40:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events_tags`
--
ALTER TABLE `events_tags`
  ADD PRIMARY KEY (`event_id`,`tag_id`),
  ADD KEY `events_tags_tags` (`tag_id`);

--
-- Indexes for table `newsletters`
--
ALTER TABLE `newsletters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `newsletter_layout_id` (`newsletter_layout_id`),
  ADD KEY `newsletter_content_id` (`newsletter_content_id`);

--
-- Indexes for table `newsletters_contents`
--
ALTER TABLE `newsletters_contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletters_layouts`
--
ALTER TABLE `newsletters_layouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_newsletters`
--
ALTER TABLE `users_newsletters`
  ADD PRIMARY KEY (`hash`),
  ADD KEY `user_id` (`user_id`,`newsletter_id`),
  ADD KEY `users_newsletters_newsletters` (`newsletter_id`);

--
-- Indexes for table `users_tags`
--
ALTER TABLE `users_tags`
  ADD PRIMARY KEY (`user_id`,`tag_id`),
  ADD KEY `users_tags_tags` (`tag_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `newsletters`
--
ALTER TABLE `newsletters`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `newsletters_contents`
--
ALTER TABLE `newsletters_contents`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `newsletters_layouts`
--
ALTER TABLE `newsletters_layouts`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `events_tags`
--
ALTER TABLE `events_tags`
  ADD CONSTRAINT `events_tags_events` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `events_tags_tags` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `newsletters`
--
ALTER TABLE `newsletters`
  ADD CONSTRAINT `newsletters_newsletters_contents` FOREIGN KEY (`newsletter_content_id`) REFERENCES `newsletters_contents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `newsletters_newsletters_layouts` FOREIGN KEY (`newsletter_layout_id`) REFERENCES `newsletters_layouts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users_newsletters`
--
ALTER TABLE `users_newsletters`
  ADD CONSTRAINT `users_newsletters_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_newsletters_newsletters` FOREIGN KEY (`newsletter_id`) REFERENCES `newsletters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users_tags`
--
ALTER TABLE `users_tags`
  ADD CONSTRAINT `users_tags_tags` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_tags_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
